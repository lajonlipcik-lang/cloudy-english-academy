quests/ — quests() + стили заданий (неделя серии, сундук, карточки)
animations/ — все keyframes и режимы анимаций (плавные / спокойные / выключены)
Часть анимаций (float, wob, pop, rise2, spin, glow) определена в оригинальном cloudy-english.css, поэтому animations.css подключать после него.
