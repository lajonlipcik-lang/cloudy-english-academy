/* Экран «Задания» — функция quests() из cloudy-english-app.js */
function quests(){const g=S.set.goal,td=S.td,rdy=td.xp>=g&&!td.claim,nr=Object.keys(S.mis).length,
 Q=[["Набери "+g+" XP",td.xp,g,"bolt"],["Пройди 2 урока",td.les,2,"book"],["Дай 12 верных ответов",td.ok,12,"target"]],
 wd=["Пн","Вт","Ср","Чт","Пт","Сб","Вс"],now=new Date(),dow=(now.getDay()+6)%7,
 week=wd.map((w,k)=>{const d=new Date(now);d.setDate(now.getDate()-dow+k);const on=S.days.includes(dk(d));return `<div class="wd${on?" on":""}${k==dow?" now":""}" style="--i:${k}"><small>${w}</small><i>${on?ic("flame"):""}</i></div>`}).join("");
 return `<div class="pg-head"><h2>Задания дня</h2><button class="hud-gear" aria-label="Настройки" onclick="CloudyUI.open()">${ic("gear")}</button></div>
 <div class="streak-card"><div class="sc-top"><span class="sc-fl">${ic("flame")}</span><div><b>${S.streak}</b><small>дней подряд</small></div></div><div class="week">${week}</div></div>
 <div class="chest-card ${rdy?"rdy":td.claim?"got":""}"><span class="cc-ic">${ic("chest")}</span><div class="cc-b"><b>Сундук дня</b><small>${td.claim?"Награда получена":Math.min(td.xp,g)+" из "+g+" XP"}</small><div class="pb"><i style="width:${Math.min(td.xp/g,1)*100}%"></i></div></div><button class="btn sm" ${rdy?"":"disabled"} onclick="claim()">${td.claim?"Получено":"Забрать"}</button></div>
 ${nr?`<div class="rv-card"><span class="rv-ic">${ic("redo")}</span><div style="flex:1"><b>Повторение ошибок</b><small>Слов для повторения: ${nr}</small></div><button class="btn sm" onclick="review()">ПОВТОРИТЬ</button></div>`:""}
 <div class="quest-list">${Q.map(([nm,v,m,icn],k)=>`<div class="qi${v>=m?" done":""}" style="--i:${k}"><span class="qi-ic">${ic(icn)}</span><div class="qi-b"><p><span>${nm}</span><b>${Math.min(v,m)}/${m}</b></p><div class="pb"><i style="width:${Math.min(v/m,1)*100}%"></i></div></div><span class="qi-ok">${ic("check")}</span></div>`).join("")}</div>`}

