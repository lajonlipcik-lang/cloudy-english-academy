/* Видео (TikTok-стиль): shorts-функции из cloudy-english-app.js */
const shortsItems=[
let shortsComposerMode="video",shortsSelectedImageUrl="",shortsSelectedImageFile=null;
let shortsFeedMode="for-you",shortsLiked=new Set(),shortsSaved=new Set(),shortsFollowing=new Set(),shortsMuted=true,shortsSelectedUrl="",shortsSelectedFile=null,shortsUploadMeta=null,shortsLiveItems=[],shortsFeedLoading=false,shortsFeedUser=null; 
let shortsProfileUserId=null,shortsProfileData=null,shortsProfileLoading=false,shortsProfileTab="all";
function shortsOpenAccountProfile(){shortsProfileUserId=null;shortsProfileData=null;shortsProfileLoading=false;shortsProfileTab="all";T=3;shortsPauseAll();view(1,-1);}
function shortsOpenMyCreatorProfile(){
function shortsOpenProfile(userId){
function shortsCloseProfile(){shortsProfileUserId=null;shortsProfileData=null;shortsProfileTab="all";T=4;view(0);}
function shortsSetProfileTab(tab){shortsProfileTab=["all","video","image","text"].includes(tab)?tab:"all";view(0);}
async function shortsToggleFollow(){
function shortsEditProfile(){
async function shortsDeletePost(postId){
function shortsCreatorProfile(){
function shortsCount(base, inc){
function shorts(){
async function shortsLoadFeed(force=false){
function shortsIcon(name){const paths={search:'<circle cx="11" cy="11" r="7"></circle><path d="m16 16 5 5"></path>',comment:'<path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H6l-3 2v-9.5A7.5 7.5 0 0 1 10.5 4h2A7.5 7.5 0 0 1 20 11.5Z"></path>',share:'<path d="M12 19V5"></path><path d="m6 11 6-6 6 6"></path><path d="M5 15v5h14v-5"></path>',bookmark:'<path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4Z"></path>',volume:'<path d="M4 10v4h4l5 4V6l-5 4Z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M18.5 6.5a9 9 0 0 1 0 11"></path>',muted:'<path d="M4 10v4h4l5 4V6l-5 4Z"></path><path d="m17 9 5 6m0-6-5 6"></path>',music:'<path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle>',menu:'<path d="M4 6h16M4 12h16M4 18h16"></path>',plus:'<path d="M12 5v14M5 12h14"></path>'};return '<svg class="shorts-svg" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(paths[name]||paths.plus)+'</svg>';}
function shortsSetMode(m){shortsFeedMode=m;view(0);}
function shortsPaintLike(x,animate=true){const card=document.querySelector('[data-short-id="'+x.id+'"]');if(!card)return;const btn=card.querySelector(".shorts-like");if(!btn)return;btn.classList.toggle("liked",!!x.isLiked);const cloud=btn.querySelector(".shorts-cloud-like");if(cloud){cloud.innerHTML=mascot(x.isLiked?"h":"s");if(animate){cloud.classList.remove("cloud-pop");void cloud.offsetWidth;cloud.classList.add("cloud-pop");}}const n=btn.querySelector("small");if(n)n.textContent=shortsCount(x.likes,false);}
async function shortsLike(id){const x=shortsLiveItems.find(v=>v.id===id);if(!x)return;if(!S.user||S.user.guest){toast("Войди в аккаунт, чтобы ставить лайки.",false);return;}const previousLiked=!!x.isLiked,previousLikes=Number(x.likes||0);x.isLiked=!previousLiked;x.likes=Math.max(0,previousLikes+(x.isLiked?1:-1));if(x.isLiked)shortsLiked.add(id);else shortsLiked.delete(id);shortsPaintLike(x,true);x.likeDesired=x.isLiked;if(x.likePending)return;x.likePending=true;try{while(x.likeSynced!==x.likeDesired){const target=x.likeDesired;const response=await authRequest("shorts-like-set",{payload:{videoId:id,like:target}});x.likeSynced=response.result?.isLiked===true;if(x.likeSynced!==target){x.likeDesired=x.likeSynced;break;}x.likes=Number(response.result?.likes??x.likes);if(x.likeDesired!==target)continue;}if(x.isLiked!==x.likeSynced){x.isLiked=x.likeSynced;x.likes=Math.max(0,Number(x.likes||0)+(x.isLiked?1:-1));if(x.isLiked)shortsLiked.add(id);else shortsLiked.delete(id);shortsPaintLike(x,false);}}catch(error){x.isLiked=previousLiked;x.likes=previousLikes;if(x.isLiked)shortsLiked.add(id);else shortsLiked.delete(id);shortsPaintLike(x,false);toast(error.message||"Не удалось сохранить лайк.",false);}finally{x.likePending=false;delete x.likeDesired;delete x.likeSynced;}}
async function shortsSave(id){if(!S.user||S.user.guest){toast("Войди в аккаунт, чтобы сохранять публикации.",false);return;}const item=shortsLiveItems.find(v=>v.id===id);if(!item||item.savePending)return;item.savePending=true;const desired=!shortsSaved.has(id);try{const response=await authRequest("shorts-save-set",{payload:{videoId:id,saved:desired}});if(response.result?.isSaved===true)shortsSaved.add(id);else shortsSaved.delete(id);item.isSaved=desired;const card=document.querySelector('[data-short-id="'+id+'"]');const btn=card?.querySelector('[aria-label="Сохранить"]');if(btn){btn.classList.toggle("saved",desired);const label=btn.querySelector("small");if(label)label.textContent=desired?"Сохранено":"Сохранить";}}catch(error){toast(error.message||"Не удалось изменить сохранённые публикации.",false);}finally{item.savePending=false;}}
async function shortsFollow(id){const x=shortsLiveItems.find(v=>v.id===id);if(!x?.authorId||x.isOwn)return;if(!S.user||S.user.guest){toast("Войди в аккаунт, чтобы подписываться.",false);return;}const next=!shortsFollowing.has(x.authorId);try{const response=await authRequest("shorts-follow-set",{payload:{authorId:x.authorId,follow:next}});if(response.result?.isFollowing)shortsFollowing.add(x.authorId);else shortsFollowing.delete(x.authorId);shortsLiveItems.forEach(item=>{if(item.authorId===x.authorId)item.isFollowingAuthor=!!response.result?.isFollowing;});document.querySelectorAll('[data-short-id="'+id+'"] .shorts-follow').forEach(btn=>{btn.classList.toggle("following",!!response.result?.isFollowing);btn.textContent=response.result?.isFollowing?"Вы подписаны":"+ Подписаться";});if(shortsFeedMode==="following")view(0);}catch(error){toast(error.message||"Не удалось изменить подписку.",false);}}
let shortsPlaybackObserver=null,shortsActiveVideo=null,shortsActiveCard=null,shortsCardVisibility=new Map();
function shortsPauseAll(except=null){document.querySelectorAll(".shorts-real-video").forEach(video=>{if(video!==except){video.pause();video.closest(".shorts-video")?.classList.remove("is-playing");}});if(!except)shortsActiveVideo=null;}
function shortsStopFeedPlayback(){
function shortsResumeFeedPlayback(){
function shortsActivateCard(card){
function shortsEvaluateVisibleCard(){
function shortsPlayVideo(video){
function shortsToggleSound(){shortsMuted=!shortsMuted;if(shortsActiveVideo)shortsActiveVideo.muted=shortsMuted;document.querySelectorAll(".sound-toggle .shorts-action-icon").forEach(x=>x.innerHTML=shortsIcon(shortsMuted?"muted":"volume"));}
async function shortsShare(id){const item=shortsLiveItems.find(x=>x.id===id);const url=location.href.split("#")[0]+"#short-"+encodeURIComponent(id);try{if(navigator.share){await navigator.share({title:"Cloudy Shorts",text:item?.caption||"Посмотри видео в Cloudy Shorts",url});}else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);toast("Ссылка на видео скопирована.");}else{toast("Поделиться сейчас не удалось.",false);}}catch(error){if(error?.name!=="AbortError")toast("Не удалось поделиться видео.",false);}}
function shortsTogglePostMenu(id){const card=Array.from(document.querySelectorAll(".shorts-video")).find(item=>item.dataset.shortId===id);if(!card)return;const wrap=card.querySelector(".shorts-post-menu-wrap");if(!wrap)return;const existing=wrap.querySelector(".shorts-post-menu");if(existing){existing.remove();wrap.querySelector("button")?.setAttribute("aria-expanded","false");return;}document.querySelectorAll(".shorts-post-menu").forEach(menu=>menu.remove());document.querySelectorAll(".shorts-post-menu-trigger").forEach(button=>button.setAttribute("aria-expanded","false"));const post=shortsLiveItems.find(item=>item.id===id);const menu=document.createElement("div");menu.className="shorts-post-menu";const share=document.createElement("button");share.type="button";share.textContent="Поделиться видео";share.addEventListener("click",()=>{menu.remove();wrap.querySelector("button")?.setAttribute("aria-expanded","false");shortsShare(id);});menu.append(share);if(post?.isOwn){const remove=document.createElement("button");remove.type="button";remove.className="danger";remove.textContent="Удалить видео";remove.addEventListener("click",()=>{menu.remove();wrap.querySelector("button")?.setAttribute("aria-expanded","false");shortsDeletePost(id);});menu.append(remove);}wrap.append(menu);wrap.querySelector("button")?.setAttribute("aria-expanded","true");}
function shortsSearch(){const q=prompt("Найти видео по английскому:");if(q?.trim())toast("Поиск подключим на следующем этапе.");}
let shortsCommentLikes=new Set(),shortsCommentSort="top",shortsReplyTo=null;
let shortsLiveComments=[],shortsLiveCommentsVideoId=null,shortsLiveCommentsLoading=false;
function shortsIsLiveId(id){return /^[0-9a-f-]{36}$/i.test(String(id||""));}
function shortsEscapeText(value){return String(value??"").replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));}
function shortsCommentTime(value){const d=new Date(value);return Number.isNaN(d.getTime())?"":d.toLocaleString("ru-RU",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"});}
async function shortsLoadLiveComments(id){
function shortsRenderComments(id){
function shortsBindCommentSheetDismiss(){
function shortsComments(id){shortsCommentSort="top";shortsReplyTo=null;shortsLiveCommentsVideoId=null;shortsLiveComments=[];sheet('<div class="shorts-comments-panel"><div class="shorts-comments-grabber"></div><header class="shorts-comments-header"><div><b>Комментарии</b><span>'+shortsCount((shortsItems.find(v=>v.id===id)||{}).comments||0,false)+'</span></div><button aria-label="Закрыть" onclick="closeSh()">'+shortsIcon("plus")+'</button></header><div class="shorts-comments-loading">Загружаем обсуждение…</div></div>');shortsRenderComments(id);}
function shortsSortComments(sort,id){shortsCommentSort=sort;shortsRenderComments(id);}
function shortsCommentLike(id){if(shortsCommentLikes.has(id))shortsCommentLikes.delete(id);else shortsCommentLikes.add(id);const videoId=$(".sb")?.dataset?.videoId||"say-tell";shortsRenderComments(videoId);}
function shortsReply(id,name){shortsReplyTo={id,name};const input=$("#shorts-comment-input");if(input){input.placeholder="Ответ для "+name+"…";input.focus();}}
function shortsToggleReplies(id){const el=$("#shorts-replies-"+id);if(el)el.classList.toggle("open");}
async function shortsSendComment(){
function shortsFormatSize(bytes){if(!Number.isFinite(bytes)||bytes<0)return "—";return bytes>=1024*1024?(bytes/1024/1024).toFixed(1)+" МБ":Math.max(1,Math.round(bytes/1024))+" КБ";}
function shortsFormatDuration(seconds){if(!Number.isFinite(seconds)||seconds<0)return "—";const total=Math.round(seconds),m=Math.floor(total/60),s=total%60;return m+":"+String(s).padStart(2,"0");}
let shortsCaptureMode=15;
let shortsFlowFrame=null,shortsFlowOverlay=null,shortsFlowFile=null;
function shortsFlowClose(resumeFeed=true){
function shortsUpload(){
function shortsSetComposerMode(mode){
function shortsSetCaptureMode(seconds,button){
function shortsCaptionCount(){const input=$("#shorts-upload-caption"),count=$("#shorts-caption-count");if(count&&input)count.textContent=input.value.length+" / 180";}
function shortsDisposeUpload(){
function shortsUploadError(message){
function shortsChooseFile(input,source="gallery"){
function shortsRemoveFile(){
function shortsChooseImage(input){
function shortsTextCount(){const field=$("#shorts-text-content"),counter=$("#shorts-text-count"),button=$("#shorts-text-submit");const length=String(field?.value||"").trim().length;if(counter)counter.textContent=String(field?.value||"").length+" / 500";if(button)button.disabled=length<1;}
async function shortsSubmitImage(){
async function shortsSubmitTextPost(){
async function shortsSubmitUpload(){
let shortsExternalPublishInProgress=false;
async function shortsPublishExternal(detail){
