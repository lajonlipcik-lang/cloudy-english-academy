profile/ — prof() + стили профиля
settings/ — settings.js (= cloudy-ui.js: панель, языки, шрифты, анимации, жесты видео) + settings.css
shorts/ — shorts-функции + стили ленты как в TikTok
settings.js грузить до cloudy-english-app.js; стили — после cloudy-english.css.
Нижняя панель (nav) живёт в cloudy-english-app.js.
